package com.cs.ssm.service;

public interface IStudentSerivce {

}
