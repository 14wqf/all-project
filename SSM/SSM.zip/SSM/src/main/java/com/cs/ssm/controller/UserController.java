package com.cs.ssm.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.cs.ssm.model.User;
import com.cs.ssm.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController {
	private static Logger log = LoggerFactory.getLogger(UserController.class);

	@Resource
	private IUserService userService;
	
	@RequestMapping(value="/test",method=RequestMethod.GET) 
	public String test(HttpServletRequest request,Model model){
		int userId = Integer.parseInt(request.getParameter("id"));
		System.out.println("userId:"+userId);
		User user = null;
		if(userId==1){
			user = new User();
			user.setAge(11);
			user.setId(1);
			user.setPassword("123");
			user.setUserName("SSM");
		}
		log.debug(user.toString());
		model.addAttribute("user", user);
		return "index";
	}
	
	/**
	 * ���Բ�ѯȫ������
	 * */
	@RequestMapping("selectAll")
	public ResponseEntity getList(Model model){
		List<User> list = userService.getSelect();
		model.addAttribute("list", list);
		return new ResponseEntity(list,HttpStatus.OK); 
	}
	
	/**
	 * ���Բ�ѯһ������
	 * */
	@RequestMapping(value="/cs-sql",method=RequestMethod.GET) 
	public ResponseEntity<User>  getUserInJson2(HttpServletRequest request,Map<String, Object> model){  
        int userId = Integer.parseInt(request.getParameter("id"));  
        System.out.println("userId:"+userId);
        User user = this.userService.getUserById(userId);  
        log.info(user.toString());
        return new ResponseEntity<User>(user,HttpStatus.OK);  
    }
	
	/**
	 * ��������һ������
	 * */
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public ResponseEntity<User> addUser(@RequestParam("username") String username, @RequestParam("pwd") String pwd, @RequestParam("age") Integer age, Model model){
		User user = new User();
		user.setUserName(username);
		user.setPassword(pwd);
		user.setAge(age);
		userService.getInsert(user);
		log.info(user.toString());
		return new ResponseEntity<User>(user,HttpStatus.OK);
	}
	
	/**
	 * �����޸�һ������
	 * */
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public ResponseEntity<User> updateUser(@RequestParam("username") String username, @RequestParam("pwd") String pwd, @RequestParam("age") Integer age, @RequestParam("id") Integer id, Model model){
		User yuan = this.userService.getUserById(id);
		log.info(yuan.toString());
		User user = new User();
		user.setId(id);
		user.setUserName(username);
		user.setPassword(pwd);
		user.setAge(age);
		userService.getUpdate(user);
		log.info(user.toString());
		return new ResponseEntity<User>(user,HttpStatus.OK);
	}
	
	/**
	 * ����ɾ��һ������
	 * */
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ResponseEntity<String> deleteUser(@RequestParam("id") Integer id){
		userService.getDelete(id);
		log.info("ɾ��");
		return new ResponseEntity<String>("delete",HttpStatus.OK);
	}
	
	/**
	 * URLģ��
	 * */
	@RequestMapping(value="/cs-url/{id}",method=RequestMethod.GET) 
	public ResponseEntity<User>  getUserInJson2(@PathVariable String id,Map<String, Object> model){  
        int userId = Integer.parseInt(id);  
        System.out.println("userId:"+userId);
        User user = this.userService.getUserById(userId);  
        log.info(user.toString());
        return new ResponseEntity<User>(user,HttpStatus.OK);  
    }
	
}
