package com.cs.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cs.ssm.dao.IUserDAO;
import com.cs.ssm.model.User;
import com.cs.ssm.service.IUserService;

@Service("userService")
public class UserServiceImpl implements IUserService{
	@Resource
	private IUserDAO userDao;
	
	//��(ȫ��)
	public List<User> getSelect(){
		return this.userDao.selectALL();
	}
	
	//��(һ��)
	public User getUserById(int userId){
		return this.userDao.selectByPrimaryKey(userId);
	}
	
	//����
	public int getInsert(User user){
		return this.userDao.insert(user);
	}
	
	//�޸�
	public int getUpdate(User user){
		return this.userDao.updateByPrimaryKey(user);
	}
	
	//ɾ��
	public int getDelete(int userId){
		return this.userDao.deleteByPrimaryKey(userId);
	}
}
