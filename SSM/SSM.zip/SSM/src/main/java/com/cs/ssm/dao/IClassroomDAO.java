package com.cs.ssm.dao;

import com.cs.ssm.model.Classroom;

public interface IClassroomDAO {
    int deleteByPrimaryKey(Integer id);

    int insert(Classroom record);

    int insertSelective(Classroom record);

    Classroom selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Classroom record);

    int updateByPrimaryKey(Classroom record);
    
    Classroom selectByName(String name);
}