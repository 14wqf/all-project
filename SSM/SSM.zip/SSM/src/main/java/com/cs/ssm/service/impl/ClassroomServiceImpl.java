package com.cs.ssm.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.cs.ssm.dao.IClassroomDAO;
import com.cs.ssm.model.Classroom;
import com.cs.ssm.service.IClassroomService;

@Service("classroomService")
public class ClassroomServiceImpl implements IClassroomService{
	@Resource
	private IClassroomDAO classroomDao;
	
	public Classroom getselectById(Integer id) {
		return this.classroomDao.selectByPrimaryKey(id);
	}
	
	public Classroom getselectByName(String name) {
		return this.classroomDao.selectByName(name);
	}
}
