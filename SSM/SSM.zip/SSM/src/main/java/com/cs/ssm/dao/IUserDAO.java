package com.cs.ssm.dao;

import java.util.List;

import com.cs.ssm.model.User;

public interface IUserDAO {
	List<User> selectALL();
	
    int deleteByPrimaryKey(Integer id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
}