package com.cs.ssm.dao;

import com.cs.ssm.model.Student;

public interface IStudentDAO {
    int deleteByPrimaryKey(Integer id);

    int insert(Student record);

    int insertSelective(Student record);

    Student selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Student record);

    int updateByPrimaryKey(Student record);
    
    Student selectStudentById(Integer id);
}