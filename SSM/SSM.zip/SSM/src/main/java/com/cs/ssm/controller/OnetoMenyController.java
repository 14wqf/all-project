package com.cs.ssm.controller;


import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cs.ssm.model.Classroom;
import com.cs.ssm.service.IClassroomService;
//import com.sun.javafx.collections.MappingChange.Map;

@Controller
@RequestMapping("/onetomeny")
public class OnetoMenyController {
	private static Logger logger = LoggerFactory.getLogger(OnetoMenyController.class);
	
	@Resource
	private IClassroomService classroomService;
	
	@RequestMapping(value="select",method=RequestMethod.GET)
	public ResponseEntity<Classroom> getSelect(HttpServletRequest request,Map<String, Object> model){
		String name = request.getParameter("name");
		Classroom classroom = this.classroomService.getselectByName(name);
		logger.info(classroom.toString());
		return new ResponseEntity<Classroom>(classroom,HttpStatus.OK);
	}
}
