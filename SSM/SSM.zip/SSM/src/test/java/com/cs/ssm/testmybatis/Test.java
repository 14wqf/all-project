package com.cs.ssm.testmybatis;

import java.io.Reader;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import com.cs.ssm.model.Classroom;
import com.cs.ssm.model.Student;

public class Test {
	 private static SqlSessionFactory sqlSessionFactory;  
	    private static Reader reader;  
	    static {  
	        try {  
	            reader = Resources.getResourceAsReader("spring-mybatis.xml");  
	            sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	    }  
	  
	    /* 
	     * һ��һ������ѯ 
	     */  
//	    public static void selectTicketById(int id) {  
//	        SqlSession session = null;  
//	        try {  
//	            session = sqlSessionFactory.openSession();  
//	            Ticket ticket = (Ticket) session.selectOne(  
//	                    "com.mucfc.model.TicketMapper.selectTicketById", id);  
//	            if (ticket == null)  
//	                System.out.println("null");  
//	            else {  
//	                System.out.println(ticket);  
//	                System.out.println(ticket.getCustomer());  
//	            }  
//	        } finally {  
//	            session.close();  
//	        }  
//	    }  
	  
	    /* 
	     * һ�Զ������ѯ 
	     */  
	    public static void selectCustomerByName(String string) {  
	        SqlSession session = null;  
	        try {  
	            session = sqlSessionFactory.openSession();  
	            Classroom classroom = (Classroom) session  
	                    .selectOne(  
	                            "com.mucfc.model.CustomerMapper.selectCustomerByName",  
	                            string);  
	            if (classroom == null)  
	                System.out.println("null");  
	            else {  
	                System.out.println(classroom);  
	                List<Student> students = classroom.getStudent();  
	                for (Student student : students) {  
	                    System.out.println(student);  
	                }  
	            }  
	        } finally {  
	            session.close();  
	        }  
	    }  
	  
	    public static void main(String[] args) {  
//	        System.out.println("==============һ��һ��ѯ�����ݳ�Ʊ����˿�===============");  
//	        selectTicketById(1);  
	        System.out.println("==============���һ��ѯ�����ݹ˿����鳵Ʊ===============");  
	        selectCustomerByName("�����");  
	  
	    }  
}
