package com.cs.ssm.testmybatis;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.cs.ssm.model.User;
import com.cs.ssm.service.IUserService;


@RunWith(SpringJUnit4ClassRunner.class)     //��ʾ�̳���SpringJUnit4ClassRunner��  
@ContextConfiguration(locations = {"classpath:spring-mybatis.xml"})  
public class TestMyBatis {
	private static Logger logger = Logger.getLogger(TestMyBatis.class);
//	private ApplicationContext ac = null;
	@Resource
//	private IUserService userService = null;
	
//	@Before
//	public void before(){
//		ac = new ClassPathXmlApplicationContext("applicationContext.xml");
//	}
	
	@Test
	public void test(){
//		List<User> user = userService.getSelect();
//		User user = userService.getUserById(2);
		
//		System.out.println(user.getUserName());
//		logger.info("ֵ��"+user.getUserName());
//		logger.info(JSON.toJSONString(user));
//		Classroom classroom = classroomService.getClassroomById(1);
//		System.out.println("�ࣺ"+classroom.getcName());
	}
}
